# Usta_Aziz — Android ilova

Ilova `http://213.230.72.78:8000/` saytini ochadi. Sayt har safar internetdan yuklanadi,
shuning uchun **saytni o‘zgartirsangiz — ilovada ham avtomatik o‘zgaradi. APK’ni qayta yig‘ish kerak emas.**
(Ilova har ochilganda keshni tozalaydi, shuning uchun yangi dizayn darhol ko‘rinadi.)

## APK’ni olish — 1-usul: GitHub (kompyutersiz ham bo‘ladi, bepul)

1. https://github.com da ro‘yxatdan o‘ting.
2. **New repository** → nomi `Usta_Aziz` → **Create repository**.
3. **uploading an existing file** havolasini bosing va shu papkadagi **barcha fayllarni**
   (`.github` papkasi bilan birga!) sudrab tashlang → **Commit changes**.
   > `.github` papkasi yashirin bo‘lishi mumkin. Agar yuklanmasa: repo’da **Add file → Create new file**,
   > nomiga `.github/workflows/build-apk.yml` yozing va shu faylning ichini nusxalab qo‘ying.
4. **Actions** bo‘limiga o‘ting — “APK yig‘ish” avtomatik boshlanadi (3–5 daqiqa).
5. Tugagach, repo’ning **Releases** bo‘limida `Usta_Aziz.apk` paydo bo‘ladi — telefondan yuklab o‘rnating.

## APK’ni olish — 2-usul: Android Studio

1. Android Studio → **Open** → shu `Usta_Aziz` papkasini tanlang.
2. Pastki o‘ng burchakda **Build Variants** → `app` uchun **release** ni tanlang.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Tayyor fayl: `app/build/outputs/apk/release/app-release.apk` (imzolangan, telefonga o‘rnatish mumkin).

## Qachon APK’ni qayta yig‘ish kerak?

Faqat quyidagi hollarda:
- Sayt **manzili** (IP yoki port) o‘zgarsa → `app/src/main/res/values/strings.xml` dagi `site_url` ni o‘zgartiring.
- Ilova **nomi yoki ikonkasi** o‘zgarsa.

Qayta yig‘ganda `app/build.gradle` dagi `versionCode` ni 1 ga oshiring (1 → 2), shunda telefonda
eski ilova ustidan yangilanadi.

## Muhim
- `app/usta_aziz.jks` — ilova imzosi. **Uni o‘chirmang va yo‘qotmang**: aks holda keyingi versiya
  eski ilova ustidan o‘rnatilmaydi. Parol: `UstaAziz2026`.
- Hozir sayt `http://` (shifrlanmagan). Kelajakda domen va `https://` qilsangiz, Google Play’ga ham chiqarish osonlashadi.

## Ilova imkoniyatlari
- Saytni to‘liq ekranda ochadi, login/cookie saqlanadi
- Pastga tortib yangilash, yuklanish chizig‘i
- “Orqaga” tugmasi saytda orqaga qaytadi
- Saytdan rasm/fayl yuklash ishlaydi
- Telefon raqam, Telegram, WhatsApp, xarita havolalari o‘z ilovasida ochiladi
- Internet yo‘q bo‘lsa — “Qayta urinish” tugmali sahifa
