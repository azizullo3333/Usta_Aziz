package uz.ustaaziz.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.os.Build;
import android.os.Bundle;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * Usta_Aziz — saytni to'g'ridan-to'g'ri internetdan ochadigan ilova.
 * Sayt manzili res/values/strings.xml dagi "site_url" da.
 * Saytdagi har qanday o'zgarish ilovada avtomatik ko'rinadi — APK'ni qayta yig'ish shart emas.
 */
public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String OFFLINE_PAGE = "file:///android_asset/offline.html";

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private ValueCallback<Uri[]> filePathCallback;
    private String siteUrl;
    private String siteHost;
    private String lastFailedUrl;
    private long lastBackPress = 0;

    // Kirish ekrani
    private View splash, splashLogo, splashProgress, splashText;
    private ObjectAnimator pulse;
    private boolean splashHidden = false;
    private long splashStart;
    private static final long SPLASH_MIN_MS = 1600;   // logo kamida shuncha ko'rinadi
    private static final long SPLASH_MAX_MS = 15000;  // sayt juda sekin bo'lsa ham shundan keyin ochiladi
    private final Handler handler = new Handler(Looper.getMainLooper());

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        siteUrl = getString(R.string.site_url);
        siteHost = Uri.parse(siteUrl).getHost();

        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress);
        swipeRefresh = findViewById(R.id.swipe_refresh);

        splash = findViewById(R.id.splash);
        splashLogo = findViewById(R.id.splash_logo);
        splashProgress = findViewById(R.id.splash_progress);
        splashText = findViewById(R.id.splash_text);
        if (savedInstanceState == null) {
            startSplashAnimation();
        } else {
            splash.setVisibility(View.GONE);
            splashHidden = true;
        }

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setBlockNetworkLoads(false);

        // WebView o'zini "Chrome" deb tanishtiradi — ba'zi saytlar/serverlar
        // WebView'ga rasmni boshqacha beradi yoki umuman bermaydi.
        String ua = s.getUserAgentString()
                .replace("; wv)", ")")
                .replaceAll("Version/\\d+(\\.\\d+)*\\s", "");
        s.setUserAgentString(ua);

        WebView.setWebContentsDebuggingEnabled(true);

        // Har safar ilova ochilganda eski keshni tozalaymiz —
        // shunda saytning yangi ko'rinishi darhol chiqadi.
        webView.clearCache(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new AppWebViewClient());
        webView.setWebChromeClient(new AppChromeClient());
        webView.setDownloadListener((url, ua, cd, mime, len) -> openExternal(Uri.parse(url)));

        swipeRefresh.setOnRefreshListener(() -> {
            if (lastFailedUrl != null) {
                webView.loadUrl(lastFailedUrl);
            } else {
                webView.reload();
            }
        });
        // Sahifa yuqorisida bo'lmasa, pastga tortish yangilamasin
        swipeRefresh.setOnChildScrollUpCallback((parent, child) -> webView.getScrollY() > 0);

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(siteUrl);
        }
    }

    private class AppWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUrl(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(Uri.parse(url));
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            hideSplash();
            progressBar.setVisibility(View.GONE);
            swipeRefresh.setRefreshing(false);
            CookieManager.getInstance().flush();
            if (url != null && !url.startsWith("file:")) {
                lastFailedUrl = null;
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                showOffline(request.getUrl().toString());
            }
        }

        // Chrome sertifikat zanjiridagi kamchiliklarni o'zi to'ldiradi, WebView esa yo'q —
        // shuning uchun rasm serverida SSL muammosi bo'lsa, faqat RASMLAR uchun ruxsat beramiz.
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            String u = error.getUrl() == null ? "" : error.getUrl().toLowerCase();
            String path = u.contains("?") ? u.substring(0, u.indexOf('?')) : u;
            if (path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".png")
                    || path.endsWith(".webp") || path.endsWith(".gif") || path.endsWith(".svg")
                    || path.contains("/media/") || path.contains("/image") || path.contains("/photo")
                    || path.contains("/uploads/") || path.contains("/static/")) {
                handler.proceed();
            } else {
                handler.cancel();
            }
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                showOffline(failingUrl);
            }
        }
    }

    private void startSplashAnimation() {
        splashStart = System.currentTimeMillis();
        progressBar.setAlpha(0f);

        // Logo: kichikdan kattalashib, sakrab chiqadi
        splashLogo.setAlpha(0f);
        splashLogo.setScaleX(0.5f);
        splashLogo.setScaleY(0.5f);
        splashLogo.setTranslationY(40f);
        splashLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(750).setInterpolator(new OvershootInterpolator(1.4f))
                .withEndAction(this::startPulse).start();

        // Yuklanish chizig'i va yozuv pastdan chiqadi
        for (View v : new View[]{splashProgress, splashText}) {
            v.setAlpha(0f);
            v.setTranslationY(30f);
            v.animate().alpha(1f).translationY(0f).setStartDelay(450)
                    .setDuration(500).setInterpolator(new DecelerateInterpolator()).start();
        }

        // Xavfsizlik: sayt ochilmasa ham ma'lum vaqtdan keyin yopiladi
        handler.postDelayed(this::hideSplash, SPLASH_MAX_MS);
    }

    private void startPulse() {
        if (splashHidden) return;
        pulse = ObjectAnimator.ofPropertyValuesHolder(splashLogo,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f));
        pulse.setDuration(900);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setInterpolator(new DecelerateInterpolator());
        pulse.start();
    }

    private void hideSplash() {
        if (splashHidden) return;
        long elapsed = System.currentTimeMillis() - splashStart;
        if (elapsed < SPLASH_MIN_MS) {
            handler.postDelayed(this::hideSplash, SPLASH_MIN_MS - elapsed);
            return;
        }
        splashHidden = true;
        handler.removeCallbacksAndMessages(null);
        if (pulse != null) pulse.cancel();

        splashLogo.animate().scaleX(1.25f).scaleY(1.25f).alpha(0f)
                .setDuration(450).setInterpolator(new AccelerateInterpolator()).start();
        splashProgress.animate().alpha(0f).setDuration(250).start();
        splashText.animate().alpha(0f).setDuration(250).start();
        splash.animate().alpha(0f).setStartDelay(150).setDuration(500)
                .withEndAction(() -> {
                    splash.setVisibility(View.GONE);
                    getWindow().setStatusBarColor(android.graphics.Color.parseColor("#1F2937"));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        getWindow().getDecorView().setSystemUiVisibility(0);
                    }
                }).start();
        progressBar.animate().alpha(1f).setDuration(300).start();
    }

    private void showOffline(String failedUrl) {
        if (failedUrl != null && !failedUrl.startsWith("file:")) {
            lastFailedUrl = failedUrl;
        }
        webView.loadUrl(OFFLINE_PAGE);
    }

    /** true = ilova o'zi ochmaydi (tashqi ilovaga beradi). */
    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        // offline.html dagi "Qayta urinish" tugmasi
        if (scheme.equals("app") && host.equals("retry")) {
            webView.loadUrl(lastFailedUrl != null ? lastFailedUrl : siteUrl);
            return true;
        }

        if (scheme.equals("http") || scheme.equals("https")) {
            if (host.equals(siteHost)) return false; // o'z sayti — ilova ichida
            // Telegram, WhatsApp, Instagram, YouTube, xaritalar — o'z ilovasida ochilsin
            if (host.endsWith("t.me") || host.contains("telegram")
                    || host.endsWith("wa.me") || host.contains("whatsapp")
                    || host.contains("instagram.com") || host.contains("facebook.com")
                    || host.contains("youtube.com") || host.equals("youtu.be")
                    || host.contains("maps.google") || host.contains("goo.gl")
                    || host.contains("yandex")
                    || (host.contains("google.") && uri.getPath() != null && uri.getPath().startsWith("/maps"))) {
                openExternal(uri);
                return true;
            }
            return false; // boshqa saytlar ham ilova ichida
        }

        // tel:, sms:, mailto:, tg:, whatsapp:, geo:, intent: va h.k.
        if (scheme.equals("intent")) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                startActivity(intent);
            } catch (Exception e) {
                String fallback = null;
                try {
                    fallback = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                            .getStringExtra("browser_fallback_url");
                } catch (Exception ignored) { }
                if (fallback != null) webView.loadUrl(fallback);
            }
            return true;
        }
        openExternal(uri);
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Bu havolani ochadigan ilova topilmadi", Toast.LENGTH_SHORT).show();
        }
    }

    private class AppChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            if (newProgress >= 100) progressBar.setVisibility(View.GONE);
        }

        // Saytdagi fayl/rasm yuklash (input type="file")
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            try {
                Intent intent = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                startActivityForResult(Intent.createChooser(intent, "Fayl tanlang"), FILE_CHOOSER_REQUEST);
            } catch (ActivityNotFoundException e) {
                filePathCallback = null;
                Toast.makeText(MainActivity.this, "Fayl tanlab bo'lmadi", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                results = new Uri[n];
                for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // Orqaga: avval saytning oldingi sahifasiga qaytadi.
        // Ilovadan chiqib ketmaslik uchun — faqat 2 soniya ichida ikki marta bossa chiqadi.
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Chiqish uchun yana bir marta bosing", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
